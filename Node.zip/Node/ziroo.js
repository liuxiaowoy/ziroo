const Crawler = require("crawler");
const crawler_ziroo = require("./crawler_ziroo");

const zirooUrl = {
    '上城':'d330102',
    '下城':'d330103',
    '下沙':'d23009161',
    '余杭':'d330110',
    '拱墅':'d330105',
    '江干':'d330104',
    '滨江':'d330108',
    '萧山':'d330109',
    '西湖':'d330106',
    '钱塘新区':'d23011864',
}


Object.keys(zirooUrl).forEach((key)=>{
    Observe(key,zirooUrl[key]);

});
// crawler_ziroo('http://hz.ziroom.com/z/d330108-p3/','上城')
// http://hz.ziroom.com/z/d330108-p3/
function Observe(from,id){
    var c = new Crawler({
    rateLimit: 1000,
    skipDuplicates: true,
    callback: function (error, res, done) {
        if (error) {
            console.log(error);
        } else {
            let $ = res.$;
            let intPage = $('.next').prev().text();
            for(let i =1;i<=intPage;i++){
                crawler_ziroo('http://hz.ziroom.com/z/'+id+'-p'+i+'/',from)
            }
        }
        done();
    }
});

c.queue('http://hz.ziroom.com/z/'+id+'-p1/');
}





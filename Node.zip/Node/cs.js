var Crawler = require("crawler");
const fs = require('fs');
// const jsonFile = require('jsonfile');
function ziroo(url,from) {
    var q = new Crawler({
        rateLimit: 1000,
        skipDuplicates: true,
        callback: function (error, res, done) {
            if (error) {
                console.log(error);
            } else {
                var $ = res.$;
                let rent_list, list_json, list_id, home_name;
                rent_list = $('.rented').text();
                list_id = $('.house_sourcecode').text();
                home_name = $('.Z_village_info h3').text();
                let room = [], roomObj = {};
                //    const obj={}
                //    let iiitem;
                rent_list = rent_list.replace(/\s+/g, " ").split(/\d\d卧+/g).filter(d => d != ' ')
                // rent_list = rent_list.replace(/\s+/g, " ").split(" ").filter(d=>d)
                // rent_list = rent_list.replace(/\s+/g, " ").replace(/(\d\d)卧+/g, " ").split(" ").filter(d=>d)
                rent_list.map((item, index) => {
                    room.push(item.split(' ').filter(d => d != ''))
                })

                room.map((item, index) => {
                    roomObj[index + 1 + '卧'] = {
                        liveTime: item[0],
                        sex: item[1],
                        constellation: item[2],
                        profession: item[3]
                    }
                });
                Object.keys(roomObj).forEach((key)=>{
                    if (!roomObj || typeof roomObj !== 'object') {
                        return
                      }
                      Observe(roomObj[key])            
                });
                function Observe(val){
                     Object.keys(val).forEach((key)=>{
                    if(val[key] === null || val[key] == undefined){
                        val[key] = '未知'
                    }
                  });
                }
                
                const obj = { [home_name + '-' + list_id]: roomObj }
                console.log(obj)
                fs.appendFile(from+'.json', JSON.stringify(obj) + '\r\n', (err) => {
                    if (err) throw err;
                    console.log('已写入到'+from+'.json');
                });

            }
            done();
        }
    });

    // URL请求队列
    q.queue(url);
}

module.exports =ziroo
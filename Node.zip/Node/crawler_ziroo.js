const Crawler = require("crawler");
const ziroo = require('./cs');

function crawler_ziroo(url,from){
    var c = new Crawler({
    rateLimit: 1000,
    skipDuplicates: true,
    callback: function (error, res, done) {
        if (error) {
            console.log(error);
        } else {
            let $ = res.$;
            let LinkArr, Restring, intPage = $.html();
            let r = /<a[^>]*href=['"]([^"]*)['"][^>]*class=\"pic-wrap\">/g;
            let t = /\/\/*([^"]*)/g;
            Restring = intPage.match(r).toString().match(t).toString()
            LinkArr = Restring.replace('undefined', '').replace(/,/g, "").split('//')
            LinkArr.shift();
            LinkArr = LinkArr.map((n) => {
                return 'http://' + n;
            });
            console.log(LinkArr);
            ziroo(LinkArr,from)

            return LinkArr;
        }
        done();
    }
});
c.queue(url);
}



module.exports = crawler_ziroo;


